<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="en-us" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Laporan</title>

</head>

<body>

<body style="background-color: #999991">
<h1>
<p style="text-align:center">Menu Laporan</p>
</h1>
<p>&nbsp;</p>
<p style="text-align:center">1.<a href="laporan_kas_masuk.php" target="_blank">Laporan Kas Masuk</a></p>
<p style="text-align:center">2.<a href="laporan_kas_keluar.php" target="_blank">Laporan Kas Keluar</a></p>
<p style="text-align:center">3.<a href="jurnal_keluar_masuk.php" target="_blank">Jurnal Keluar Masuk</a></p>

<p>&nbsp;</p>

</body>

</html>
