<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Layanan Perbankan</title>
</head>

<body>
<body style="background-color: #999991">
<h1>
<p style="text-align:center">Layanan Perbankan</p>
</h1>



<p>&nbsp;</p>
<p style="text-align:center">1. <a href="master_nasabah.php" target="_blank">Buka Rekening</a></p>
<p style="text-align:center">2. <a href="mutasi_masuk.php" target="_blank">Mutasi Masuk</a></p>
<p style="text-align:center">3. <a href="mutasi_keluar.php" target="_blank">Mutasi Keluar</a></p>
<p style="text-align:center">4. <a href="mutasi_transfer.php" target="_blank">Transfer</a></p>
<p style="text-align:center">5. <a href="cari_transaksi.php" target="_blank">Cari Transaksi</a></p>


</body>

</html>
