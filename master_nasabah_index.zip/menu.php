<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="en-us" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>menu minibank</title>
</head>

<body>

<body style="background-color: #999991">
<h1>
<p style="text-align:center">Master Data</p>
</h1>
<p>&nbsp;</p>
<p style="text-align:center">1. <a href="master_nasabah.php" target="_blank">nasabah</a></p>
<p style="text-align:center">2. <a href="master_tabungan.php" target="_blank">jenis program</a></p>
<p style="text-align:center">3. <a href="kode_transaksi.php" target="_blank">kode transaksi</a></p>
</body>

</html>
