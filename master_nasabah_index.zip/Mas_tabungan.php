<?php

class Mas_tabungan {
    public $kode_tabungan;
    public $nama_tabungan;
    public $setoran_minimal;
}

?>