<?php

class mas_nasabah_var {
    public $kode_nasabah;
    public $nama_nasabah;
    public $alamat_nasabah;
    public $tgl_lahir_nasabah;
    public $nama_ibu_kandung;
    public $no_tlp_nasabah;

}

?>