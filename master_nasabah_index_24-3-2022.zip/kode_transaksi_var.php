<?php

class kode_transaksi_var {
    public $kode_transaksi;
    public $ket_transaksi;
    public $jenis_neraca;
}

?>