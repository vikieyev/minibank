<?php

return array(
    "db" => "mysql:host=127.0.0.1;dbname=minibank",
    "username" => "root",
    "password" => ""
);

?>
